#ifndef CSV_CONSTANTS_H_
#define CSV_CONSTANTS_H_

static const char kDefaultSeparator = ',';
static const char kQuotechar = '\"';

#endif /* CSV_CONSTANTS_H_ */
