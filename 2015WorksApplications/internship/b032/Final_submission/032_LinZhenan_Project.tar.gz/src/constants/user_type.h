#ifndef USERTYPE_H_
#define USERTYPE_H_

using namespace std;

enum UserType
{
	CUSTOMER = 1,
	RECEPTIONIST,
	WAITER,
	HR,
	SALES_MANAGER,
	HOTEL_MANAGER,
	COMPANY_MANAGER,
};

#endif
